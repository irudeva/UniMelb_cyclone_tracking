c Include file "cyc2.h"

c     Cyclone parameters

      character chead*80
      common /blcyc3/chead

      integer da,hr
      common /blcyc4/da,hr,nk,
     * itabc1,itabc2,itabc3,itabc4,itabc5

