c Include file 'trk1.h'
c     Tracking parameters
      integer da0,hr0,ddhmt
      logical rsttks
      COMMON /bltrk01/da0,hr0,ddhmt,iopmxt,cmnt1,cmnt2,refdt
     *, iadvtp,wsteer,fsteer,asteer,wmotn,wpten
     *, dequiv,rcprob,rpbell,qmxopn,qmxwek,qmxnew
     *, nsort,irevmx,merget,qmerge,rsttks
     *, itabt1,itabt2,itabt3,itabt4,itabt5

