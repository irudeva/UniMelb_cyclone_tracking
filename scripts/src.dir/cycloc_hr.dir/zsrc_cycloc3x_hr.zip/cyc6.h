c Include file "cyc6.h"

c     Derivatives for Taylor series expansion

      common /blfmn0/fmn0(0:3,0:3)

