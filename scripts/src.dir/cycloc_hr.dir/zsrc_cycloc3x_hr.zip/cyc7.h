      common /blfxy1/f(nar2lt)
      common /blfxy2/fxx(nar2lt)
      common /blfxy3/fyy(nar2lt)
      common /blfxy4/fxxyy(nar2lt)
