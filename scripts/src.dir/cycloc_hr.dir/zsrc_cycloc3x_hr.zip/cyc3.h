c Include file "cyc3.h"

c     Projection parameters and limits

      character grid*17,hemis*1
      common /blcyc5/grid,hemis

      common /blcyc6/ni,nj,xcen,ycen,rproj,fhem,imnc,imxc,
     * jmnc,jmxc,alatlt,spval

